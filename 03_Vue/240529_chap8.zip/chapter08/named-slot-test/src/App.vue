<template>
  <div>
    <SlotTest />
    <namedSlotTest />
  </div>
</template>

<script>
import SlotTest from './components/SlotTest.vue';
export default {
  name: 'App',
  components: { SlotTest, NamedSlotTest },
};
</script>
