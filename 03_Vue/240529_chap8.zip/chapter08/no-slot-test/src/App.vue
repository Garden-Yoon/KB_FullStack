<template>
  <div>
    <NoSlotTest />
  </div>
</template>

<script>
import NoSlotTest from './components/NoSlotTest.vue';
export default {
  name: 'App',
  components: { NoSlotTest },
};
</script>
